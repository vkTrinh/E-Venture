from django.apps import AppConfig


class CommunicationConfig(AppConfig):
    name = 'Communication'
