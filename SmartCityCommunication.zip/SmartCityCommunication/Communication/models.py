from django.db import models
# Create your models here.

class Sender(models.Model):
    wann = models.DateTimeField(auto_now_add=True); 
    von = models.EmailField();
    grund = models.CharField(max_length=95);
    nachricht = models.TextField();
    def __str__(self):
        return self.wann.strftime('%Y/%b/%d;%H:%M:%S')+ ";" + self.von + ";" + self.grund
        
# class addressand so dass man 30 E-Mail pro Tag verarbeiten kann
#class Addressee(models.Model):
        
        
 